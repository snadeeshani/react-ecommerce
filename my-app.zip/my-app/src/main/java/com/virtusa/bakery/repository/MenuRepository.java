//package com.virtusa.bakery.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.virtusa.bakery.model.Menu;
//
//public interface MenuRepository extends JpaRepository<Menu , Integer> {
//
//}
