package com.virtusa.bakery.service;

import org.springframework.http.ResponseEntity;

public interface MenuService {
	
	ResponseEntity fetchMenuList();

}
